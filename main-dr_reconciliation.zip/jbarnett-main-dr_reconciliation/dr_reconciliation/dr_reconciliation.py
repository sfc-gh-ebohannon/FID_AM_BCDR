import logging
import json
import sql_constants as SQL_CONSTANTS
import streamlit as st
from time import time
from pandas import DataFrame
from typing import NamedTuple
from pprint import pprint, pformat
from snowflake.snowpark.session import Session
#from snowflake_db_util import execute_nonquery, execute_scaler, execute_query
from textwrap import dedent
import common.whitebear as wb

@st.cache_resource
def init_session(connection_parameters):
    return Session.builder.configs(connection_parameters).create()

class DrReconciliation:
    DEFAULT_LOGGING_CONFIG = {
    "level": logging.INFO,
    "format": "%(asctime)s [%(levelname)s] %(message)s",
    "handlers": [logging.StreamHandler()]
  }     
  
    logging.basicConfig(**DEFAULT_LOGGING_CONFIG)

    def __init__(self, 
        primary_session_parameters: str,
        secondary_session_parameters: str,
        failover_group: str,
        target_prefix = "__",
        target_suffix = "__",
        logger_config = None,
        debug = False) -> bool:
    
        logger_config = logger_config if logger_config is not None else self.DEFAULT_LOGGING_CONFIG
        logging.basicConfig(**logger_config)

        self.primary_session_parameters = primary_session_parameters
        self.primary_session = init_session(primary_session_parameters)
        self.secondary_session_parameters = secondary_session_parameters
        self.secondary_session = init_session(secondary_session_parameters)
        self.failover_group = failover_group
        self.target_prefix = target_prefix
        self.target_suffix = target_suffix
        self.debug = debug

        self.target_copy_history_table = f"{target_prefix}COPY_HISTORY{target_suffix}"
        self.target_query_history_table = f"{target_prefix}QUERY_HISTORY{target_suffix}"
        self.target_statements_table = f"{target_prefix}STATEMENTS{target_suffix}"
        


    ################################################################################################
    # Utility functions
    ################################################################################################
    def execute_scalar(self, session, query, parameters=None):
        if (self.debug):
          print(query)
        return session.sql(query).collect()[0][0]

    def execute_resultset(self, session, query, parameters=None):
        if (self.debug):
          print(query)

        return session.sql(query).collect()

    def execute_nonquery(self, session, query, parameters=None):
        if (self.debug):
          print(query)

        return session.sql(query).collect()
    
    def execute_snowpark_dataframe(self, session, query, parameters=None):
        if (self.debug):
          print(query)

        return session.sql(query)

    def execute_pandas_dataframe(self, session, query, parameters=None):
        if (self.debug):
          print(query)

        return session.sql(query).to_pandas()
    

    ################################################################################################
    # Applicaton Methods
    ################################################################################################
    def get_failover_groups(self, connection):
          st.session_state.connection = connection
          query = SQL_CONSTANTS.QUERY_SHOW_FAILOVER_GROUPS
          return wb.run_query(query)
    

    def get_connections(connection):
          st.session_state.connection = connection
          query = SQL_CONSTANTS.QUERY_SHOW_CONNECTIONS
          return wb.run_query(query)


    def get_refresh_history(self, connection, failover_group):
        st.session_state.connection = connection

        query = SQL_CONSTANTS.QUERY_LAST_REPLICATION.format(failover_group=failover_group)
        df = wb.run_query(query)
        return df['LAST_REPLICATION_TIME'].values[0]


    def is_primary_region(self, connection, failover_group):
        query = SQL_CONSTANTS.QUERY_IS_PRIMARY.format(failover_group=failover_group)
        st.session_state.connection = connection
        df = wb.run_query(query)
        return df['IS_PRIMARY'].values[0]


    def get_account_info(self, connection, failover_group):
        query = SQL_CONSTANTS.QUERY_ACCOUNT_INFO.format(failover_group=failover_group)
        st.session_state.connection = connection
        df = wb.run_query(query)
        return df


    def get_pipe_count(self):
        query = SQL_CONSTANTS.QUERY_PIPE_COUNT
        return self.execute_scalar(self.primary_session, query)


    def get_pipes(self):
        query = SQL_CONSTANTS.QUERY_SHOW_PIPES
        return self.execute_resultset(self.primary_session, query)


    def make_account_primary(self, failover_group):
        query = SQL_CONSTANTS.QUERY_MAKE_ACCOUNT_PRIMARY.format(failover_group=failover_group)
        self.execute_nonquery(self.secondary_session, query)
        return True
    

    def activate_pipes(self):
        query = SQL_CONSTANTS.QUERY_ACTIVATE_PIPES
        return self.execute_scalar(self.primary_session, query)


    def refresh_copy_history(self):
        query = SQL_CONSTANTS.QUERY_LAST_REPLICATION.format(failover_group=self.failover_group)
        df = wb.run_query(query)
        last_replication_time = df['LAST_REPLICATION_TIME'].values[0]
        print(f"{last_replication_time=} in refresh_copy_history")

        logging.info(f"Saving temporary copy_history as {self.target_copy_history_table}")
        query = SQL_CONSTANTS.QUERY_COPY_HISTORY.format(source='PRIMARY', last_replication_time=last_replication_time)
        primary_copy_history_df = self.primary_session.sql(query)
        primary_copy_history_df.write.mode("overwrite").save_as_table(f"{self.target_copy_history_table}")

        logging.info(f"Adding Secondary items to table {self.target_copy_history_table}")
        query = SQL_CONSTANTS.QUERY_COPY_HISTORY.format(source='SECONDARY', last_replication_time=last_replication_time)
        secondary_copy_history_pdf = self.secondary_session.sql(query).to_pandas()
        self.primary_session.write_pandas(secondary_copy_history_pdf, table_name=f"{self.target_copy_history_table}", auto_create_table=False, overwrite=False, use_logical_type=True)

        logging.info(f"Copying partial query_history over to the primary as table {self.target_query_history_table}")
        query = SQL_CONSTANTS.QUERY_QUERY_HISTORY.format(last_replication_time=last_replication_time)
        secondary_query_history_pdf = self.secondary_session.sql(query).to_pandas()
        self.primary_session.write_pandas(secondary_query_history_pdf, table_name=self.target_query_history_table, auto_create_table=True, overwrite=True, use_logical_type=True)

        copy_history_count = self.execute_scalar(self.primary_session, f"select count(*) as cnt from {self.target_copy_history_table}")
        query_history_count = self.execute_scalar(self.primary_session, f"select count(*) as cnt from {self.target_query_history_table}")

        return {"copy_history_count": copy_history_count, "query_history_count": query_history_count}


    def get_copy_history(self):
        query = f"select * from {self.target_copy_history_table}"
        return self.primary_session.sql(query).to_pandas()

    def get_query_history(self):
        query = f"select * from {self.target_query_history_table}"
        return self.primary_session.sql(query).to_pandas()
    
    def get_copy_catchup_statements(self, run=False):
        query = SQL_CONSTANTS.QUERY_COPY_INTO_CATCHUP.format(
            statements_table = self.target_statements_table,
            query_history_table = self.target_query_history_table)
        
        self.execute_nonquery(self.primary_session, query)

        query = SQL_CONSTANTS.QUERY_RUN_STATEMENTS.format(statements_table=self.target_statements_table )
        return self.primary_session.sql(query).to_pandas()
    
    def get_reconciliation_report(self):
        query = SQL_CONSTANTS.QUERY_RECONCILIATION_REPORT
        return self.primary_session.sql(query).to_pandas()
    
    def get_fubar(self):
        query = "select * from SNOWFLAKE_SAMPLE_DATA.TPCDS_SF10TCL.ITEM"
        print(query)
        return self.secondary_session.sql(query).to_pandas()
