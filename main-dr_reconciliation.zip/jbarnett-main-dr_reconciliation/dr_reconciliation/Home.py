import streamlit as st
import pandas as pd
import tomli
from pprint import pprint

st.set_page_config(
        page_title = 'Snowflake',
        layout     = 'wide',
        page_icon  = 'resources/favicon.png')
st.title("Snowflake Account Reconciliation")

secrets = tomli.load(open(".streamlit/secrets.toml", "rb"))
connection_list = list(secrets.keys())

def account_to_dataframe(config):        
    data = {
        'Property': [
            "account_locator",
            "account_name",
            "connection",
            "display_name",
            "is_primary",
            "last_replication_time",
            "organization_name",
            "snowflake_region"],
        'Value': [
            str(config.get("ACCOUNT_LOCATOR")),  
            str(config.get("ACCOUNT_NAME")),
            str(config.get("connection")),
            str(config.get("DISPLAY_NAME")),
            str(config.get("IS_PRIMARY")),
            str(config.get("LAST_REPLICATION_TIME")),
            str(config.get("ORGANIZATION_NAME")),
            str(config.get("SNOWFLAKE_REGION"))]
        }

    return pd.DataFrame(data)

# Required Session_State Variable 
if 'connection' not in st.session_state:
    st.session_state['connection'] = connection_list[0]
if 'debug' not in st.session_state:
    st.session_state['debug'] = False
if 'ttl' not in st.session_state:
    st.session_state['ttl'] = 600

from common import whitebear as wb
import dr_reconciliation

# Load Account Information toml file
with open("data/accounts.toml", mode="rb") as fp:
     accounts = tomli.load(fp)
df = pd.DataFrame(accounts)

primary_account_info = wb.get_session_state("primary_account_info")
secondary_account_info = wb.get_session_state("secondary_account_info")

account_1 = wb.account_selector(title="Account 1", key="account_1")
account_2 = wb.account_selector(title="Account 2", key="account_2")

if (account_1 and account_2):
    # Start out with the two accounts regardless of who is primary
    dr = dr_reconciliation.DrReconciliation(secrets.get(account_1['connection']), secrets.get(account_2['connection']), '')
    with st.spinner("Getting fail over groups..."):
        failover_groups = dr.get_failover_groups(account_1['connection'])
    failover_groups_df = failover_groups["name"].unique()
    failover_group = st.selectbox("Failover Group",failover_groups_df, placeholder="---")
    with st.spinner("Getting connections..."):
        connections_df = dr.get_failover_groups(account_1['connection'])
    #st.dataframe(connections_df)

disable = False if account_1 and account_2 and failover_group else True
refresh_btn = st.button('Refresh',disabled=disable)

if refresh_btn:
    with st.spinner("Looking up accounts..."):
        account_1_connection = account_1['connection']
        account_2_connection = account_2['connection']

        failover_groups_1 = dr.get_failover_groups(account_1_connection)
        failover_groups_2 = dr.get_failover_groups(account_1_connection)

        is_primary_1 = dr.is_primary_region(account_1_connection, failover_group)
        is_primary_2 = dr.is_primary_region(account_2_connection, failover_group)

        account_info_1 = dr.get_account_info(account_1_connection, failover_group).loc[0].to_dict()
        account_info_1['connection'] = account_1_connection
        account_info_1['failover_group'] = failover_group
        account_info_1['connection_parameters'] = secrets.get(account_1_connection)
        account_info_1['IS_PRIMARY'] = is_primary_1
        account_info_1['DISPLAY_NAME'] = f"{account_info_1['ORGANIZATION_NAME']}-{account_info_1['ACCOUNT_NAME']} ({account_info_1['SNOWFLAKE_REGION']})"

        account_info_2 = dr.get_account_info(account_2_connection, failover_group).loc[0].to_dict()
        account_info_2['connection'] = account_2_connection
        account_info_2['failover_group'] = failover_group
        account_info_2['connection_parameters'] = secrets.get(account_2_connection)
        account_info_2['IS_PRIMARY'] = is_primary_2
        account_info_2['DISPLAY_NAME'] = f"{account_info_2['ORGANIZATION_NAME']}-{account_info_2['ACCOUNT_NAME']} ({account_info_2['SNOWFLAKE_REGION']})"
    
    if (is_primary_1 and is_primary_2):
        raise(Exception("Both accounts are primary"))

    if (is_primary_1 == False and is_primary_2 == False):
        raise(Exception("Neither account is primary"))
    
    if (is_primary_1):
        primary_account = account_1
        primary_account_info = account_info_1
        secondary_account = account_2
        secondary_account_info = account_info_2
    else:
        primary_account = account_2
        primary_account_info = account_info_2
        secondary_account = account_1
        secondary_account_info = account_info_1

    # Save for other pages
    st.session_state.primary_account_info = primary_account_info
    st.session_state.secondary_account_info = secondary_account_info

regions_selected = primary_account_info is not None and secondary_account_info is not None
if (regions_selected):
    st.subheader("Failover Group")
    st.html(f"<b>{primary_account_info['failover_group']}</b>")

    col1, col2 = st.columns(2, vertical_alignment="top", border=True)
    with col1:
        st.subheader("Primary Account")
        st.html(f"<b>{primary_account_info['DISPLAY_NAME']}</b>")
        st.dataframe(account_to_dataframe(primary_account_info), hide_index=True)
    with col2:
        st.subheader("Secondary Account")
        st.html(f"<b>{secondary_account_info['DISPLAY_NAME']}</b>")
        st.dataframe(account_to_dataframe(secondary_account_info), hide_index=True)
        include_connection = st.checkbox("Failover connection")
        make_primary = st.button("Make Primary")
        if (make_primary):
            # TODO: Add Confirmation dialog
            dr = dr_reconciliation.DrReconciliation(
                primary_account_info['connection_parameters'],
                secondary_account_info['connection_parameters'], 
                primary_account_info['failover_group'])
            dr.make_account_primary(primary_account_info['failover_group'])
            st.toast(f"Successfully failed over")