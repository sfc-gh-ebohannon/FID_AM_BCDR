
QUERY_LAST_REPLICATION = """
SELECT TO_VARCHAR(start_time) as last_replication_time
FROM   TABLE(INFORMATION_SCHEMA.REPLICATION_GROUP_REFRESH_HISTORY('{failover_group}'))
WHERE  phase_name = 'COMPLETED'
ORDER  BY end_time DESC
LIMIT  1
"""

QUERY_COPY_HISTORY = """
SELECT 
    CAST('{source}' AS VARCHAR(20)) AS source,
    file_name,
    stage_location,
    last_load_time,
    row_count,
    row_parsed,
    file_size,
    first_error_message,
    error_count,
    error_limit,
    status,
    table_name,
    table_schema_name,
    table_catalog_name,
    pipe_catalog_name,
    pipe_schema_name,
    pipe_name,
    pipe_received_time,
    first_commit_time
FROM  snowflake.account_usage.copy_history
WHERE COALESCE(pipe_received_time, '1900-01-01') >= TO_TIMESTAMP_LTZ('{last_replication_time}')
OR    last_load_time >= TO_TIMESTAMP_LTZ('{last_replication_time}')
"""

QUERY_QUERY_HISTORY = """
SELECT 
    query_id,
    start_time,
    execution_status,
    query_type,
    query_text
FROM  snowflake.account_usage.query_history
WHERE query_type = 'COPY'
AND   start_time >= TO_TIMESTAMP_LTZ('{last_replication_time}')
"""

QUERY_COPY_INTO_CATCHUP = """
create or replace transient table {statements_table} DATA_RETENTION_TIME_IN_DAYS=0
as
select query_text as statement
from   {query_history_table} as qh 
where  1=1
and    qh.execution_status = 'SUCCESS'
and    qh.query_type = 'COPY'
and    qh.query_text ilike '%COPY%INTO%'
order  by start_time;
"""

QUERY_RUN_STATEMENTS = """
select statement from {statements_table} order by statement
"""

QUERY_CALL_SP_EXECUTESQL = """
CALL SP_EXECUTE_SQL('{query}', {ignore_errors}, {dry_run})
"""

QUERY_SHOW_CONNECTIONS = """
SHOW CONNECTIONS
"""

QUERY_SHOW_FAILOVER_GROUPS = """
SHOW FAILOVER GROUPS
"""

# Enhanced query to add databases for the failover group
QUERY_GET_FAILOVER_GROUP = """
 execute immediate
    $$
    declare
    res resultset;
    sql varchar;
    query_id_1 VARCHAR;
    query_id_2 VARCHAR;
    begin
        sql := 'show failover groups like ''{failover_group}''';
        execute immediate :sql;
        query_id_1 := last_query_id();

        sql := 'show databases in failover group {failover_group}';
        execute immediate :sql;
        query_id_2 := last_query_id();

        res := (
        select *
        from table(result_scan(:query_id_1)) as fg
        left join (
            select array_agg("name") as databases
            from table(result_scan(:query_id_1))
        ) db);

        return table(res);  
    end;
    $$
""" 

QUERY_MAKE_ACCOUNT_PRIMARY = """
    ALTER FAILOVER GROUP {failover_group} PRIMARY
""" 

QUERY_LAST_REPLICATION = """
    SELECT TO_VARCHAR(start_time) as last_replication_time
    FROM   TABLE(INFORMATION_SCHEMA.REPLICATION_GROUP_REFRESH_HISTORY('{failover_group}'))
    WHERE  phase_name = 'COMPLETED'
    ORDER  BY end_time DESC
    LIMIT  1
"""

QUERY_IS_PRIMARY = """
    execute immediate
    $$
    declare
    res resultset;
    sql varchar;
    begin
        sql := 'show failover groups like ''{failover_group}''';
        execute immediate :sql;
        sql := '
            select CAST("is_primary" as boolean) as is_primary
            from table(result_scan(last_query_id()))
            where "organization_name" = current_organization_name()
            and "account_locator" = current_account()';

        res := (execute immediate :sql);
        return table(res);  
    end;
    $$
"""

QUERY_ACCOUNT_INFO = """
   WITH RH AS
    (
        SELECT TO_VARCHAR(start_time) as last_replication_time
        FROM   SNOWFLAKE.ACCOUNT_USAGE.REPLICATION_GROUP_REFRESH_HISTORY
        WHERE  REPLICATION_GROUP_NAME = '{failover_group}'
        AND    PHASE_NAME = 'COMPLETED'
        UNION
        SELECT TO_VARCHAR(start_time) as last_replication_time
        FROM   TABLE(INFORMATION_SCHEMA.REPLICATION_GROUP_REFRESH_HISTORY('{failover_group}'))
        WHERE  phase_name = 'COMPLETED'
        ORDER  BY 1 DESC 
        LIMIT  1
    ), 
    INFO AS 
    (
        select 
            current_region() as snowflake_region, 
            current_account_name() as account_name,
            current_organization_name() as organization_name,
            current_account() as account_locator
    )
    SELECT INFO.*, RH.last_replication_time
    FROM   info
    LEFT   join RH
    ON     1=1
"""

QUERY_SHOW_PIPES = """
    SHOW PIPES IN ACCOUNT
"""

QUERY_PIPE_COUNT = """
    EXECUTE IMMEDIATE
    $$
    declare
    res resultset;
    sql varchar;
    begin
        sql := 'show pipes in account';
        execute immediate :sql;
        
        sql := 'select count(*) as pipe_count
            from table(result_scan(last_query_id()))';
        res := (execute immediate :sql);
        return table(res);  
    end;
    $$
"""

# TODO: Change to call
QUERY_ACTIVATE_PIPES = """
EXECUTE IMMEDIATE
$$
declare
    res resultset;
    pipe_name varchar;
    sql varchar;
    i int := 0;
  begin
    sql := 'show pipes in account';
    res := (execute immediate :sql);
    let c2 cursor for res;
    for r in c2 do
      pipe_name := 
  UPPER(r."database_name" || '.' || r."schema_name" || '.' || r."name");
      sql := 'SELECT SYSTEM$ACTIVATE_PIPE(''' || pipe_name || ''')';
      execute immediate :sql;
      i := i + 1;
    end for;
    return i;
  end;
$$;
"""

QUERY_RECONCILIATION_REPORT = """
SELECT 
    FILE_NAME,
    STAGE_LOCATION,
    STATUS,
    CASE WHEN orig.pipe_name is null THEN 'COPY' ELSE 'PIPE' END AS load_type,
    LAST_LOAD_TIME,
    TABLE_CATALOG_NAME AS DATABASE_NAME,    
    TABLE_SCHEMA_NAME AS SCHEMA_NAME,
    TABLE_NAME,
    ROW_COUNT,
    ROW_PARSED,
    FILE_SIZE
FROM __COPY_HISTORY__ AS orig
WHERE orig.source = 'SECONDARY'
AND NOT EXISTS (
	SELECT *
	FROM   snowflake.account_usage.copy_history AS curr
	WHERE  orig.file_name = curr.file_name
    and    orig.stage_location = curr.stage_location
    and    orig.table_catalog_name = curr.table_catalog_name
   	and    orig.table_schema_name = curr.table_schema_name
    and    orig.table_name = curr.table_name
)
"""