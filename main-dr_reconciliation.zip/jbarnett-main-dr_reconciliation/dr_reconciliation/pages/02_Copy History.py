import streamlit as st
from common import whitebear as wb
import dr_reconciliation
from pprint import pprint

st.header('Copy History')

primary_account_info = wb.get_session_state("primary_account_info")
secondary_account_info = wb.get_session_state("secondary_account_info")
regions_selected = primary_account_info is not None and secondary_account_info is not None

if (regions_selected):
    dr = dr_reconciliation.DrReconciliation(
        primary_account_info['connection_parameters'],
        secondary_account_info['connection_parameters'], 
        primary_account_info['failover_group'])
    
    with st.sidebar:
        refresh_btn = st.button('Refresh Copy History',disabled=False)

    st.subheader("Primary Account")
    st.divider()
    st.html(f"<b>{primary_account_info['DISPLAY_NAME']}</b>")
    
    if refresh_btn:
        with st.spinner("Refreshing Copy and Query History..."):
            results = dr.refresh_copy_history()
        st.info('History refreshed!')
        st.write(results)

        with st.spinner("Retrieving Copy and Query History..."):
            copy_history_pdf = dr.get_copy_history()
            query_history_pdf = dr.get_query_history()
        st.subheader("Copy History")
        st.dataframe(copy_history_pdf, use_container_width=True, hide_index=True)
        st.subheader("Query History")
        st.dataframe(query_history_pdf, use_container_width=True, hide_index=True)

        with st.spinner("Creating Copy 'Catch up' statements..."):
            catchup_statements = dr.get_copy_catchup_statements(run=False)
        st.dataframe(catchup_statements, use_container_width=True, hide_index=True)

else:
    st.info('Navigate to the Home Page and refresh the regions and availablity group')
    st.page_link("Home.py", label="Home", icon="🏠")

