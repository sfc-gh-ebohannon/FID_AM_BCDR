import streamlit as st
from common import whitebear as wb
import dr_reconciliation

st.header('Activate Pipes')

primary_account_info = wb.get_session_state("primary_account_info")
secondary_account_info = wb.get_session_state("secondary_account_info")
regions_selected = primary_account_info is not None and secondary_account_info is not None

if (regions_selected):
    dr = dr_reconciliation.DrReconciliation(
        primary_account_info['connection_parameters'],
        secondary_account_info['connection_parameters'], 
        primary_account_info['failover_group'])

    with st.spinner("Counting Pipes..."):
        pipe_count = dr.get_pipe_count()
    with st.spinner("Retrieving Pipes..."):
        pipes_pdf = dr.get_pipes()
    disable = False if (pipe_count > 0) else True

    col1 = st.columns(1)
    col1, col2 = st.columns(2)
    col1.metric(label="Active Account", value=primary_account_info['DISPLAY_NAME'])
    col1.metric(label="Number of Pipes", value=pipe_count)
    with st.expander("Pipes"):
            st.dataframe(pipes_pdf, hide_index=True)

    with st.sidebar:
        refresh_btn = st.button('Activate',disabled=disable)
    
    # TODO: Add confirmation dialog
    if refresh_btn:
        with st.spinner("Activating Pipes..."):
            activated_count = dr.activate_pipes()
        st.info(f'Activated {activated_count} pipes.') 
else:
    st.info('Navigate to the Home Page and refresh the regions and availablity group')
    st.page_link("Home.py", label="Home", icon="🏠")
