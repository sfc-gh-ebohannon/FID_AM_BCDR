import streamlit as st
from common import whitebear as wb
import dr_reconciliation
from pprint import pprint

st.header('Reconciliation Report')

primary_account_info = wb.get_session_state("primary_account_info")
secondary_account_info = wb.get_session_state("secondary_account_info")
regions_selected = primary_account_info is not None and secondary_account_info is not None

if (regions_selected):
    dr = dr_reconciliation.DrReconciliation(
        primary_account_info['connection_parameters'],
        secondary_account_info['connection_parameters'], 
        primary_account_info['failover_group'])
    
    with st.spinner("Refreshing..."):
        df = dr.get_reconciliation_report()
        st.dataframe(df, use_container_width=True, hide_index=True)
    
    foo = st.button("Refresh")
else:
    st.info('Navigate to the Home Page and refresh the regions and availablity group')
    st.page_link("Home.py", label="Home", icon="🏠")

