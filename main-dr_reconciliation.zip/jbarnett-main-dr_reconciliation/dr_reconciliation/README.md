# DR Reconciliation
This Streamlit app assists in performing and validating a cross-region failover. 

## Features
1. Examine two accounts (defined in a config file) to determine which is primary and secondary

2. Execute the failover command to swap primary

3. Redirect a named connection (TO BE DONE)

4. Activate pipes in the new primary

5. Bring copy and query history metadata from the secondary to the primary and compare

6. Generate copy statements to execute "catch up" loads for data loaded using the COPY INTO command

7. Generate a reconciliation report showing files not loaded (either through pipes or COPY INTO)

## Setup
1. Create a conda enviroment with the required dependincies.   
```bash
conda env create -f environment.yml
```
2. Active the environment
```bash
conda activate dr_reconciliation
```
3. Start the streamlit app (after updating configuration)
```bash
streamlit run Home.py
```

## Config Files
The config files must be updated before running the application.
### accounts.toml
The *data/accounts.toml* file is utilized to store information regarding one or multiple Snowflake accounts. 
The values contained in this file serve as variables that are utilized in queries and Python scripts.  

Modify the section names and values to align with the Snowflake account values you will access. 
The section name, such as [PROD-ACCOUNT], will appear (sorted) as options in the account select box in your Streamlit apps. 
At least two account entries are required.

### secrets.toml
The .streamlit/secrets.toml file is a configuration file used by the Streamlit.  It contains the databases credentials needed to access Snowflake. 

The key names in the secrets.toml must match the "connection" property of the accounts in the accounts.toml.
